"""Verify native payloads; system install/upgrade/uninstall runs only on disposable CI runners."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import sqlite3
import subprocess
import tempfile


def native_check(executable,report):
    result=subprocess.run([str(executable),'--self-test','--self-test-report',str(report)],timeout=120)
    if result.returncode or not report.is_file():raise RuntimeError('Installed application self-test failed.')
    data=json.loads(report.read_text())
    if not data.get('passed'):raise RuntimeError(data.get('error','Native acceptance checks failed.'))
    return data


def verify(package,output,previous=None,system_install=False):
    package=Path(package).resolve();output=Path(output).resolve();output.mkdir(parents=True,exist_ok=True)
    system=platform.system()
    if system_install and not (os.environ.get('GITHUB_ACTIONS')=='true' and os.environ.get('CI')=='true'):
        raise RuntimeError('System installation checks require a disposable GitHub Actions runner.')
    if previous and not system_install and system!='Darwin':
        raise RuntimeError('A previous-release upgrade check requires system-install mode.')
    os.environ.update(QT_QPA_PLATFORM='offscreen',ODT_NO_SETUP='1')
    report={'platform':system,'package':package.name,'system_install':system_install,'passed':False}
    with tempfile.TemporaryDirectory(prefix='odt-install-check-') as directory:
        scratch=Path(directory);profile=None
        data=scratch/'user-data'
        if system_install:
            if system=='Windows':base=Path(os.environ.get('APPDATA',Path.home()/'AppData/Roaming'))
            elif system=='Darwin':base=Path.home()/'Library/Application Support'
            else:base=Path(os.environ.get('XDG_CONFIG_HOME',Path.home()/'.config'))
            profile=base/'offline-document-toolkit'
            if profile.exists():raise RuntimeError('An existing app profile was found; use a clean disposable runner.')
            data=profile/'workspace'
        data.mkdir(parents=True)
        sentinel=data/'keep-me.txt';sentinel.write_text('Synthetic user data survives installation changes')
        database=data/'workspace.sqlite3'
        with sqlite3.connect(database) as db:
            db.execute('CREATE TABLE projects(id TEXT PRIMARY KEY,name TEXT,document TEXT,updated REAL)')
            db.execute('INSERT INTO projects VALUES(?,?,?,?)',('fixture','Preserved project',json.dumps({'assets':{},'pages':[]}),0))
        expected=hashlib.sha256(database.read_bytes()).hexdigest()
        def preserved():
            assert sentinel.read_text()=='Synthetic user data survives installation changes'
            assert hashlib.sha256(database.read_bytes()).hexdigest()==expected
        if system=='Linux':
            if system_install:
                def install(path):subprocess.run(['sudo','-n','apt-get','install','-y',str(path)],check=True)
                if previous:install(Path(previous).resolve());preserved()
                install(package);preserved()
                executable=Path('/opt/offline-document-toolkit/OfflineDocumentToolkit')
                report['native']=native_check(executable,output/'native-self-test.json')
                if not previous:install(package);preserved()
                subprocess.run(['sudo','-n','apt-get','remove','-y','offline-document-toolkit'],check=True);preserved()
                assert not executable.exists()
            else:
                target=scratch/'payload';subprocess.run(['dpkg-deb','--extract',str(package),str(target)],check=True)
                report['native']=native_check(target/'opt/offline-document-toolkit/OfflineDocumentToolkit',output/'native-self-test.json')
                preserved()
        elif system=='Windows':
            if not system_install:raise RuntimeError('Use the CI system-install check for Windows installers.')
            target=scratch/'application'
            def install(path):subprocess.run([str(path),'/VERYSILENT','/SUPPRESSMSGBOXES','/NORESTART',f'/DIR={target}'],check=True)
            if previous:install(Path(previous).resolve());preserved()
            install(package);preserved()
            report['native']=native_check(target/'OfflineDocumentToolkit.exe',output/'native-self-test.json')
            if not previous:install(package);preserved()
            uninstaller=next(target.glob('unins*.exe'))
            subprocess.run([str(uninstaller),'/VERYSILENT','/SUPPRESSMSGBOXES','/NORESTART'],check=True);preserved()
            assert not (target/'OfflineDocumentToolkit.exe').exists()
        elif system=='Darwin':
            target=scratch/'applications/OfflineDocumentToolkit.app';target.parent.mkdir()
            def install(path):
                mount=scratch/'mount';mount.mkdir(exist_ok=True)
                subprocess.run(['hdiutil','attach',str(path),'-nobrowse','-mountpoint',str(mount)],check=True)
                try:
                    if target.exists():shutil.rmtree(target)
                    subprocess.run(['ditto',str(mount/'OfflineDocumentToolkit.app'),str(target)],check=True)
                finally:subprocess.run(['hdiutil','detach',str(mount)],check=True)
            if previous:install(Path(previous).resolve());preserved()
            install(package);preserved()
            report['native']=native_check(target/'Contents/MacOS/OfflineDocumentToolkit',output/'native-self-test.json')
            if not previous:install(package);preserved()
            shutil.rmtree(target);preserved();assert not target.exists()
        else:raise RuntimeError('Unsupported installer platform.')
        if profile:shutil.rmtree(profile)
        report.update(passed=True,user_data_preserved=True,user_data_check='default-app-profile' if system_install else 'temporary-fixture',
            upgrade='previous-release-to-current' if previous else ('current-version-reinstall' if system_install or system=='Darwin' else 'not-run'),
            uninstall=bool(system_install or system=='Darwin'))
    (output/'installer-validation.json').write_text(json.dumps(report,indent=2)+'\n')
    return report


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('package',type=Path)
    parser.add_argument('--output',type=Path,default=Path('release/installer-validation'))
    parser.add_argument('--previous',type=Path);parser.add_argument('--system-install',action='store_true')
    args=parser.parse_args();print(json.dumps(verify(args.package,args.output,args.previous,args.system_install)))


if __name__=='__main__':main()
