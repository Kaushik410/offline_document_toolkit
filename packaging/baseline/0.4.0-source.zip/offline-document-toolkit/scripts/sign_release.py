"""Sign and verify native artifacts using identities already installed on the target OS."""
import argparse
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess


def windows_sign(path,thumbprint):
    compiler=shutil.which('signtool')
    if not compiler:
        root=Path(os.environ.get('ProgramFiles(x86)','C:/Program Files (x86)'))/'Windows Kits/10/bin'
        candidates=sorted(root.glob('*/x64/signtool.exe'),reverse=True)
        compiler=str(candidates[0]) if candidates else None
    if not compiler:raise RuntimeError('Install the Windows SDK signing tools.')
    subprocess.run([compiler,'sign','/fd','SHA256','/td','SHA256','/tr','http://timestamp.digicert.com',
                    '/sha1',thumbprint,str(path)],check=True)
    subprocess.run([compiler,'verify','/pa','/all',str(path)],check=True)


def sign(path,notarize=False,required=False):
    path=Path(path)
    if not path.exists():raise FileNotFoundError(path)
    system=platform.system()
    if system=='Windows':
        identity=os.environ.get('ODT_WINDOWS_CERT_SHA1')
        if identity:windows_sign(path,identity);return {'artifact':str(path),'status':'signed-and-verified'}
    elif system=='Darwin':
        identity=os.environ.get('ODT_MAC_SIGN_IDENTITY')
        if identity:
            # PyInstaller signs nested code with the same identity during build.
            # Re-sign the outer app or disk image, then verify the complete result.
            subprocess.run(['codesign','--force','--options','runtime','--timestamp','--sign',identity,str(path)],check=True)
            subprocess.run(['codesign','--verify','--deep','--strict','--verbose=2',str(path)],check=True)
            if notarize:
                profile=os.environ.get('ODT_NOTARY_PROFILE')
                if not profile:raise RuntimeError('Configure ODT_NOTARY_PROFILE in the signing keychain.')
                subprocess.run(['xcrun','notarytool','submit',str(path),'--keychain-profile',profile,'--wait'],check=True)
                subprocess.run(['xcrun','stapler','staple',str(path)],check=True)
                subprocess.run(['xcrun','stapler','validate',str(path)],check=True)
            return {'artifact':str(path),'status':'notarized-and-verified' if notarize else 'signed-and-verified'}
    if required:raise RuntimeError('A signing identity for the target OS has not been configured.')
    return {'artifact':str(path),'status':'unsigned','reason':'No target-OS signing identity configured'}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('artifact',type=Path)
    parser.add_argument('--notarize',action='store_true');parser.add_argument('--required',action='store_true')
    parser.add_argument('--report',type=Path)
    args=parser.parse_args();result=sign(args.artifact,args.notarize,args.required)
    if args.report:args.report.parent.mkdir(parents=True,exist_ok=True);args.report.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))


if __name__=='__main__':main()
